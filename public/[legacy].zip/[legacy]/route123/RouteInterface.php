<?php

interface RouteInterface
{
    public function route(): string;
}